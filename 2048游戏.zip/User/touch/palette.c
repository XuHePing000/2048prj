#include "./touch/palette.h"
#include "./touch/gt9xx.h"
#include "./lcd/bsp_lcd.h"
 
/*��ť�ṹ������*/
Touch_Button button;

/*���ʲ���*/
Brush_Style  			brush;
Block_Colour 			Block_Colour_BUFF[12];
Block_place  			Block_place_BUFF[16];

Direction_Struct        Direction_Structure;

Direction_Struct_FLAG   Direction_Structure_FLAG;//�������ұ�־

uint16_t interface[16] = {0};//16���������

uint8_t Status_flag = 0;  //���»��ɿ���־

static void Draw_Color_Button(void *btn);

void Print_Interface(uint16_t * Interface);

void Block_Colour_init(void)
{
	Direction_Structure.Down  = 0;                //��ʼ������ṹ��
	Direction_Structure.Left  = 0;
	Direction_Structure.Right = 0;
	Direction_Structure.Up    = 0;
	
	Block_Colour_BUFF[0].Block_Color = CL_WHITE;  //2     �ⶼ�ǰ�ÿ�����ֶ�Ӧ����ɫ������ֱ�ӵ��ýṹ��������ܹ�����ĸ�����ʾ
	Block_Colour_BUFF[0].Num_Color = CL_GREY3;	
	Block_Colour_BUFF[0].CHAR[0] = '0';
	Block_Colour_BUFF[0].CHAR[1] = '0';
	Block_Colour_BUFF[0].CHAR[2] = '0';
	Block_Colour_BUFF[0].CHAR[3] = '2';	
	
	Block_Colour_BUFF[1].Block_Color = CL_BLACK;  //4
	Block_Colour_BUFF[1].Num_Color = CL_WHITE;	
	Block_Colour_BUFF[1].CHAR[0] = '0';
	Block_Colour_BUFF[1].CHAR[1] = '0';
	Block_Colour_BUFF[1].CHAR[2] = '0';
	Block_Colour_BUFF[1].CHAR[3] = '4';	

	Block_Colour_BUFF[2].Block_Color = CL_RED;    //8
	Block_Colour_BUFF[2].Num_Color = CL_WHITE;	
	Block_Colour_BUFF[2].CHAR[0] = '0';
	Block_Colour_BUFF[2].CHAR[1] = '0';
	Block_Colour_BUFF[2].CHAR[2] = '0';
	Block_Colour_BUFF[2].CHAR[3] = '8';	

	Block_Colour_BUFF[3].Block_Color = CL_GREEN;  //16
	Block_Colour_BUFF[3].Num_Color = CL_WHITE;	
	Block_Colour_BUFF[3].CHAR[0] = '0';
	Block_Colour_BUFF[3].CHAR[1] = '0';
	Block_Colour_BUFF[3].CHAR[2] = '1';
	Block_Colour_BUFF[3].CHAR[3] = '6';	

	Block_Colour_BUFF[4].Block_Color = CL_BLUE;   //32
	Block_Colour_BUFF[4].Num_Color = CL_WHITE;
	Block_Colour_BUFF[4].CHAR[0] = '0';
	Block_Colour_BUFF[4].CHAR[1] = '0';
	Block_Colour_BUFF[4].CHAR[2] = '3';
	Block_Colour_BUFF[4].CHAR[3] = '2';	
	
	Block_Colour_BUFF[5].Block_Color = CL_YELLOW; //64
	Block_Colour_BUFF[5].Num_Color = CL_GREY3;
	Block_Colour_BUFF[5].CHAR[0] = '0';
	Block_Colour_BUFF[5].CHAR[1] = '0';
	Block_Colour_BUFF[5].CHAR[2] = '6';
	Block_Colour_BUFF[5].CHAR[3] = '4';	
	
	Block_Colour_BUFF[6].Block_Color = CL_GREY;   //128
	Block_Colour_BUFF[6].Num_Color = CL_WHITE;
	Block_Colour_BUFF[6].CHAR[0] = '0';
	Block_Colour_BUFF[6].CHAR[1] = '1';
	Block_Colour_BUFF[6].CHAR[2] = '2';
	Block_Colour_BUFF[6].CHAR[3] = '8';	
	
	Block_Colour_BUFF[7].Block_Color = CL_GREY3;  //256
	Block_Colour_BUFF[7].Num_Color = CL_GREY1;
	Block_Colour_BUFF[7].CHAR[0] = '0';
	Block_Colour_BUFF[7].CHAR[1] = '2';
	Block_Colour_BUFF[7].CHAR[2] = '5';
	Block_Colour_BUFF[7].CHAR[3] = '6';	
	
	Block_Colour_BUFF[8].Block_Color = CL_MAGENTA;//512
	Block_Colour_BUFF[8].Num_Color = CL_WHITE;
	Block_Colour_BUFF[8].CHAR[0] = '0';
	Block_Colour_BUFF[8].CHAR[1] = '5';
	Block_Colour_BUFF[8].CHAR[2] = '1';
	Block_Colour_BUFF[8].CHAR[3] = '2';	
	
	Block_Colour_BUFF[9].Block_Color = CL_CYAN;   //1024
	Block_Colour_BUFF[9].Num_Color = CL_GREY3;
	Block_Colour_BUFF[9].CHAR[0] = '1';
	Block_Colour_BUFF[9].CHAR[1] = '0';
	Block_Colour_BUFF[9].CHAR[2] = '2';
	Block_Colour_BUFF[9].CHAR[3] = '4';	
	
	Block_Colour_BUFF[10].Block_Color = CL_BLUE1; //2048
	Block_Colour_BUFF[10].Num_Color = CL_GREY3;
	Block_Colour_BUFF[10].CHAR[0] = '2';
	Block_Colour_BUFF[10].CHAR[1] = '0';
	Block_Colour_BUFF[10].CHAR[2] = '4';
	Block_Colour_BUFF[10].CHAR[3] = '8';

	Block_Colour_BUFF[11].Block_Color = CL_ZERO;  //0
	Block_Colour_BUFF[11].Num_Color = CL_GREY3;
	Block_Colour_BUFF[11].CHAR[0] = '0';
	Block_Colour_BUFF[11].CHAR[1] = '0';
	Block_Colour_BUFF[11].CHAR[2] = '0';
	Block_Colour_BUFF[11].CHAR[3] = '0';

	Block_place_BUFF[0].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH;//���1              //��Ϊ���ֶ����Ľ��棬������Щ����ÿ��С���������λ�ã�
	Block_place_BUFF[0].y_start = 0+BUTTON_AND_BUTTON_WIDTH;								  //����ֱ�ӵ��ýṹ��������ܹ��������ʾ����
	Block_place_BUFF[0].x_end   = BUTTON_START_X+COLOR_BLOCK_WIDTH+BUTTON_AND_BUTTON_WIDTH;
	Block_place_BUFF[0].y_end   = COLOR_BLOCK_HEIGHT+BUTTON_AND_BUTTON_WIDTH;
	
	Block_place_BUFF[1].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH;//���2
	Block_place_BUFF[1].y_start = COLOR_BLOCK_HEIGHT+BUTTON_AND_BUTTON_WIDTH*2;
	Block_place_BUFF[1].x_end   = BUTTON_START_X+COLOR_BLOCK_WIDTH+BUTTON_AND_BUTTON_WIDTH;
	Block_place_BUFF[1].y_end   = COLOR_BLOCK_HEIGHT*2+BUTTON_AND_BUTTON_WIDTH*2;
	
	Block_place_BUFF[2].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH;//���3
	Block_place_BUFF[2].y_start = COLOR_BLOCK_HEIGHT*2+BUTTON_AND_BUTTON_WIDTH*3;
	Block_place_BUFF[2].x_end   = BUTTON_START_X+COLOR_BLOCK_WIDTH+BUTTON_AND_BUTTON_WIDTH;
	Block_place_BUFF[2].y_end   = COLOR_BLOCK_HEIGHT*3+BUTTON_AND_BUTTON_WIDTH*3;
	
	Block_place_BUFF[3].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH;//���4
	Block_place_BUFF[3].y_start = COLOR_BLOCK_HEIGHT*3+BUTTON_AND_BUTTON_WIDTH*4;
	Block_place_BUFF[3].x_end   = BUTTON_START_X+COLOR_BLOCK_WIDTH+BUTTON_AND_BUTTON_WIDTH;
	Block_place_BUFF[3].y_end   = COLOR_BLOCK_HEIGHT*4+BUTTON_AND_BUTTON_WIDTH*4;
	
	Block_place_BUFF[4].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH;//���5
	Block_place_BUFF[4].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*1+COLOR_BLOCK_HEIGHT*0;
	Block_place_BUFF[4].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH*2;
	Block_place_BUFF[4].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH+COLOR_BLOCK_HEIGHT;
	
	Block_place_BUFF[5].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH;//���6
	Block_place_BUFF[5].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_HEIGHT;
	Block_place_BUFF[5].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH*2;
	Block_place_BUFF[5].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_HEIGHT*2;
	
	Block_place_BUFF[6].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH;//���7
	Block_place_BUFF[6].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_HEIGHT*2;
	Block_place_BUFF[6].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH*2;
	Block_place_BUFF[6].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_HEIGHT*3;
	
	Block_place_BUFF[7].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH;//���8
	Block_place_BUFF[7].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_HEIGHT*3;
	Block_place_BUFF[7].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_WIDTH*2;
	Block_place_BUFF[7].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_HEIGHT*4;
	
	Block_place_BUFF[8].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*2;//���9
	Block_place_BUFF[8].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*1+COLOR_BLOCK_HEIGHT*0;
	Block_place_BUFF[8].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*3;
	Block_place_BUFF[8].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*1+COLOR_BLOCK_HEIGHT*1;
	
	Block_place_BUFF[9].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*2;//���10
	Block_place_BUFF[9].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_HEIGHT*1;
	Block_place_BUFF[9].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*3;
	Block_place_BUFF[9].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_HEIGHT*2;
	
	Block_place_BUFF[10].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*2;//���11
	Block_place_BUFF[10].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_HEIGHT*2;
	Block_place_BUFF[10].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*3;
	Block_place_BUFF[10].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_HEIGHT*3;
	
	Block_place_BUFF[11].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*2;//���12
	Block_place_BUFF[11].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_HEIGHT*3;
	Block_place_BUFF[11].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_WIDTH*3;
	Block_place_BUFF[11].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_HEIGHT*4;
	
	Block_place_BUFF[12].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*3;//���13
	Block_place_BUFF[12].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*1+COLOR_BLOCK_HEIGHT*0;
	Block_place_BUFF[12].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*4;
	Block_place_BUFF[12].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*1+COLOR_BLOCK_HEIGHT*1;
	
	Block_place_BUFF[13].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*3;//���14
	Block_place_BUFF[13].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_HEIGHT*1;
	Block_place_BUFF[13].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*4;
	Block_place_BUFF[13].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*2+COLOR_BLOCK_HEIGHT*2;
	
	Block_place_BUFF[14].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*3;//���15
	Block_place_BUFF[14].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_HEIGHT*2;
	Block_place_BUFF[14].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*4;
	Block_place_BUFF[14].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*3+COLOR_BLOCK_HEIGHT*3;
	
	Block_place_BUFF[15].x_start = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*3;//���16
	Block_place_BUFF[15].y_start = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_HEIGHT*3;
	Block_place_BUFF[15].x_end   = BUTTON_START_X+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_WIDTH*4;
	Block_place_BUFF[15].y_end   = PALETTE_START_Y+BUTTON_AND_BUTTON_WIDTH*4+COLOR_BLOCK_HEIGHT*4;
}

/**
* @brief  Palette_Init �����ʼ��
* @param  ��
* @retval ��
*/
void Palette_Init(void)
{
	/* ������Ϊ��ɫ */
	LCD_Clear(CL_BACK);	/* ����*/

	Block_Colour_init();    //��ʼ���������

	LCD_SetColors(CL_GREY,CL_WHITE);   //����Ļ��ߵĿ�
	LCD_DrawFullRect(16,16,304,448);
	
	LCD_SetColors(CL_GREY3,CL_WHITE);
	LCD_DrawFullRect(20,20,296,440);
	
	LCD_SetColors(CL_GREY1,CL_WHITE);
	LCD_DrawFullRect(40,40,256,100);
	
	/*ѡ�����壬ʹ����Ӣ����ʾʱ��������Ӣ��ѡ���16*24�����壬
	  ���������С��24*24�ģ���Ҫ��������������������ģ
	  �������ֻ��Ӣ������������*/
	LCD_SetFont(&Font24x56);
	LCD_DispString_EN_CH(50,153,(uint8_t*)"2048",LCD_COLOR565_CYAN,0);

	LCD_DispChar_CH(110,125,0xD0A1); //'С'
	LCD_DispChar_CH(110,150,0xD3CE); //'��'
	LCD_DispChar_CH(110,175,0xCFB7); //'Ϸ'
	
	LCD_SetColors(CL_GREY1,CL_WHITE);   //���¿�ʼ��ť
	LCD_DrawFullRect(118,390,100,50);
	
	LCD_SetFont(&Font16x24);
	LCD_DispString_EN_CH(405,145,(uint8_t*)"�ؿ�",LCD_COLOR565_CYAN,1);

	LCD_SetColors(CL_YELLOW,CL_WHITE);   //����һΪ�߿���ɫ������������
	LCD_DrawRect(118,390,100,50);

//	LCD_SetFont(&Font24x56);
//	LCD_DispString_EN_CH(160,125,(uint8_t*)score_buff,LCD_COLOR565_CYAN,0);
}

/**
* @brief  Touch_Button_Init ��ʼ����ť����
* @param  Block_place:  ����λ��
		  Block_Colour�������ɫ(��ɫ��������������һ��ģ�������ɫ�������֣����ִ�����ɫ)
* @retval ��
*/
void Touch_Button_Update(uint8_t Block_place,uint16_t Block_Colour)
{
	switch(Block_Colour)
	{
		case 0:
			Block_Colour = 11;
			break;
		case 2:
			Block_Colour = 0;
			break;
		case 4:
			Block_Colour = 1;
			break;
		case 8:
			Block_Colour = 2;
			break;
		case 16:
			Block_Colour = 3;
			break;
		case 32:
			Block_Colour = 4;
			break;
		case 64:
			Block_Colour = 5;
			break;
		case 128:
			Block_Colour = 6;
			break;
		case 256:
			Block_Colour = 7;
			break;
		case 512:
			Block_Colour = 8;
			break;
		case 1024:
			Block_Colour = 9;
			break;
		case 2048:
			Block_Colour = 10;
			break;
//		defualt:
//			break;
	}
	button.start_x      = Block_place_BUFF[Block_place].x_start;
	button.start_y      = Block_place_BUFF[Block_place].y_start;
	button.end_x        = Block_place_BUFF[Block_place].x_end;
	button.end_y        = Block_place_BUFF[Block_place].y_end;
	button.Block_Color  = Block_Colour_BUFF[Block_Colour].Block_Color;
	button.Num_Color    = Block_Colour_BUFF[Block_Colour].Num_Color;
	button.CHAR_BUFF[0] = Block_Colour_BUFF[Block_Colour].CHAR[0];
	button.CHAR_BUFF[1] = Block_Colour_BUFF[Block_Colour].CHAR[1];
	button.CHAR_BUFF[2] = Block_Colour_BUFF[Block_Colour].CHAR[2];
	button.CHAR_BUFF[3] = Block_Colour_BUFF[Block_Colour].CHAR[3];
	button.draw_btn     = Draw_Color_Button ;
	
	button.draw_btn(&button);
}

void Print_Interface(uint16_t * Interface)      //����ˢ�º���
{
	uint8_t Count = 0;
	uint8_t score_buff[4] = {'1','1','1','1'};
	int SCORE = score;
	int i = 0;
	
	for(i=3;i>=0;i--)
	{
		score_buff[i] = SCORE%10+'0';       //���µ�ǰ�ļƷ�����
		SCORE /= 10;
	}
	for(Count=0;Count<16;Count++)
	{
		Touch_Button_Update(Count,Interface[Count]);   //�������еİ��
	}
	LCD_SetFont(&Font16x24);
	LCD_DispString_EN_CH(180,40,(uint8_t*)"������",LCD_COLOR565_CYAN,1);

	LCD_SetFont(&Font16x24);
	LCD_DispString_EN_CH(183,140,score_buff,CL_GREY1,2);     //���¼Ʒ���ʾ
}

/**
* @brief  Touch_Button_Down ����������ʱ���õĺ������ɴ���������
* @param  x ����λ�õ�x����
* @param  y ����λ�õ�y����
* @retval ��
*/
void Touch_Button_Down(uint32_t x,uint32_t y)
{
    if(x<800 && y<480 && y>0 && x>320&&GameOver_Flag == 0)
    {
		Status_flag = 1;
		Direction_Structure.Left = 0; //������ṹ������
		Direction_Structure.Down = 0;
		Direction_Structure.Right = 0;
		Direction_Structure.Up = 0;
		
		Direction_Structure_FLAG.Down_FLAG = 0;
		Direction_Structure_FLAG.Left_FLAG = 0;
		Direction_Structure_FLAG.Right_FLAG = 0;
		Direction_Structure_FLAG.Up_FLAG = 0;
	}
}
uint8_t Again_Flag = 0;

/**
* @brief  Touch_Button_Up �������ͷ�ʱ���õĺ������ɴ���������
* @param  x ��������ͷ�ʱ��x����
* @param  y ��������ͷ�ʱ��y����
* @retval ��
*/
void Touch_Button_Up(uint32_t x,uint32_t y)
{
	uint16_t Cnt_MAX = 0;
	uint8_t  label = 0;
	int i = 0;
	
	Status_flag = 0;//����ṹ���Ƿ�++/--��־
	
    if(x<800 && y<480 && y>0 && x>320 &&GameOver_Flag == 0)
    {
		if(Direction_Structure.Down>=Direction_Structure.Left) 
		{
			Cnt_MAX = Direction_Structure.Down;
			label = 1;
		}
		else
		{
			Cnt_MAX = Direction_Structure.Left;
			label = 2;
		}
		if(Cnt_MAX<Direction_Structure.Right) 
		{
			Cnt_MAX = Direction_Structure.Right;
			label = 3;
		}
		if(Cnt_MAX<Direction_Structure.Up)    
		{
			Cnt_MAX = Direction_Structure.Up;
			label = 4;
		}
		switch(label)
		{
		case 1:
			Direction_Structure_FLAG.Down_FLAG = 1;
			break;
		case 2:
			Direction_Structure_FLAG.Left_FLAG = 1;
			break;
		case 3:
			Direction_Structure_FLAG.Right_FLAG = 1;
			break;
		case 4:
			Direction_Structure_FLAG.Up_FLAG = 1;
			break;
		}
	}
	else if(x>118&&x<218&&y>390&&y<440)
	{
		score = 0;
		
		for(i=0;i<16;i++)
		{
			interface[i] = 0;
		}
		GameOver_Flag = 0;
		Again_Flag = 1;
	}
}

/**
* @brief  Draw_Trail �ڻ���������津���켣
* @param  pre_x ��һ���x����
* @param  pre_y ��һ���y����
* @param  x     ����һ���x����
* @param  y     ����һ���y����
* @param  brush ��ˢ����
* @retval ��
*/
void Draw_Trail(int32_t pre_x,int32_t pre_y,int32_t x,int32_t y)
{
	int32_t x_differ = 0,y_differ = 0;
	
	uint8_t Flag_x = 0,Flag_y = 0;
	
	if(Status_flag == 1)
	{
		Status_flag = 0;
		
		if(x>PALETTE_START_X && pre_x>PALETTE_START_X )
		{
			if(pre_x > x)
				Flag_x = 1;
			else if(pre_x < x)
				Flag_x = 0;
			if(pre_y > y)
				Flag_y = 1;
			else if(pre_y < y)
				Flag_y = 0;
			x_differ = ABS((pre_x - x));
			y_differ = ABS((pre_y - y));
			
			if(x_differ>y_differ&&Flag_x == 0)
				Direction_Structure.Right++;
			else if(x_differ>y_differ&&Flag_x == 1)
				Direction_Structure.Left++;
			
			if(x_differ<y_differ&&Flag_y == 0)
				Direction_Structure.Down++;
			else if(x_differ<y_differ&&Flag_y == 1)
				Direction_Structure.Up++;
		}
	}
	else
	{
	}
}

/**
* @brief  Draw_Color_Button ��ɫ��ť����溯��
* @param  btn Touch_Button ���͵İ�������
* @retval ��
*/
static void Draw_Color_Button(void *btn)
{
	Touch_Button *ptr = (Touch_Button *)btn;
	
	/*����Ϊ���ܼ���Ӧ����ɫ*/
	LCD_SetColors(ptr->Block_Color,CL_WHITE);//����һΪ�����ɫ������������
	LCD_DrawFullRect(ptr->start_x,ptr->start_y,ptr->end_x - ptr->start_x,ptr->end_y - ptr->start_y);
	
	/*��ť�߿�*/
	LCD_SetColors(CL_BLUE4,CL_WHITE);   //����һΪ�߿���ɫ������������
	LCD_DrawRect(ptr->start_x,ptr->start_y,ptr->end_x - ptr->start_x,ptr->end_y - ptr->start_y);
	
    /********************************************************************************************************/
//	LCD_SetColors(CL_BUTTON_GREY,CL_WHITE);
//	LCD_DrawFullRect(ptr->start_x,ptr->start_y,ptr->end_x - ptr->start_x,ptr->end_y - ptr->start_y);
	
//	LCD_SetColors(CL_BLACK,CL_BUTTON_GREY);
	/*ѡ�����壬ʹ����Ӣ����ʾʱ��������Ӣ��ѡ���16*24�����壬
	*���������С��24*24�ģ���Ҫ��������������������ģ*/
	/*�������ֻ��Ӣ������������*/
	LCD_SetFont(&Font24x56);
	LCD_DispString_EN_CH( ptr->start_y+(COLOR_BLOCK_HEIGHT-56)/2,ptr->start_x + (COLOR_BLOCK_WIDTH-24)/2,(uint8_t*)ptr->CHAR_BUFF,ptr->Num_Color,0);  
}

/* ------------------------------------------end of file---------------------------------------- */
